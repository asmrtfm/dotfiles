/home/nspyrd/Music/August Burns Red/[2007] Messengers/01 - The Truth Of a Liar.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/02 - Up Against the Ropes.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/03 - Back Burner.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/04 - The Blinding Light.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/05 - Composure.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/06 - Vital Signs.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/07 - The Eleventh Hour.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/08 - The Balance.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/09 - Black Sheep.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/10 - An American Dream.mp3
/home/nspyrd/Music/August Burns Red/[2007] Messengers/11 - Redemption.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/01_august_burns_red-the_wake-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/02_august_burns_red-martyr-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/03_august_burns_red-identity-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/04_august_burns_red-separating_the_seas-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/05_august_burns_red-ghosts_(feat._jeremy_mckinnon_of_a_day_to_remember)-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/06_august_burns_red-majoring_in_the_minors-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/07_august_burns_red-everlasting_ending-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/08_august_burns_red-broken_promises-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/09_august_burns_red-blackwood-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/10_august_burns_red-twenty-one_grams-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/11_august_burns_red-vanguard-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/12_august_burns_red-marathon-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/13_august_burns_red-majoring_in_the_minors_(reprise)-fih.mp3
/home/nspyrd/Music/August Burns Red/Found In Far Away Places [2015]/August_Burns_Red-Found_In_Far_Away_Places-2015-FiH/14_august_burns_red-identity_(midi)-fih.mp3
