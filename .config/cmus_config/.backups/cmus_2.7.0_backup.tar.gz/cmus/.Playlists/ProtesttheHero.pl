/home/nspyrd/Music/Protest the Hero/Volition/01 clarity.mp3
/home/nspyrd/Music/Protest the Hero/Volition/02 drumhead trial.mp3
/home/nspyrd/Music/Protest the Hero/Volition/03 tilting against windmills.mp3
/home/nspyrd/Music/Protest the Hero/Volition/04 without prejudice.mp3
/home/nspyrd/Music/Protest the Hero/Volition/05 yellow teeth.mp3
/home/nspyrd/Music/Protest the Hero/Volition/06 plato's tripartite.mp3
/home/nspyrd/Music/Protest the Hero/Volition/07 a life embossed.mp3
/home/nspyrd/Music/Protest the Hero/Volition/08 mist.mp3
/home/nspyrd/Music/Protest the Hero/Volition/09 underbite.mp3
/home/nspyrd/Music/Protest the Hero/Volition/10 animal bones.mp3
/home/nspyrd/Music/Protest the Hero/Volition/11 skies.mp3
/home/nspyrd/Music/Protest the Hero/Pacific Myth/01 - Tidal.mp3
/home/nspyrd/Music/Protest the Hero/Pacific Myth/02 - Ragged tooth.mp3
/home/nspyrd/Music/Protest the Hero/Pacific Myth/03 - Cold water.mp3
/home/nspyrd/Music/Protest the Hero/Pacific Myth/04 - Cataract.mp3
/home/nspyrd/Music/Protest the Hero/Pacific Myth/05 - Harbinger.mp3
/home/nspyrd/Music/Protest the Hero/Pacific Myth/06 - Caravan.mp3
