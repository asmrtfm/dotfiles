/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/01 - Black Sabbath.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/02 - The Wizard.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/03 - Behind The Wall Of Sleep.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/04 - N.I.B.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/05 - Evil Woman.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/06 - Sleeping Village.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/07 - Warning.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] BLACK SABBATH/08 - Wicked World.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/01 - Sweet Leaf.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/02 - After Forever.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/03 - Embryo.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/04 - Children Of The Grave.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/05 - Orchid.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/06 - Lord Of This World.mp3
/home/nspyrd/Music/BLACK SABBATH/[1971] MASTER OF REALITY/08 - Into The Void.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] PARANOID/03 - Planet Caravan.mp3
/home/nspyrd/Music/BLACK SABBATH/[1970] PARANOID/07 - Rat Salad.mp3
/home/nspyrd/Music/BLACK SABBATH/[1973] SABBATH BLOODY SABBATH/01 - Sabbath Bloody Sabbath.mp3
/home/nspyrd/Music/BLACK SABBATH/[1973] SABBATH BLOODY SABBATH/08 - Spiral Architect.mp3
/home/nspyrd/Music/BLACK SABBATH/[1975] SABOTAGE/01 - Hole In The Sky.mp3
