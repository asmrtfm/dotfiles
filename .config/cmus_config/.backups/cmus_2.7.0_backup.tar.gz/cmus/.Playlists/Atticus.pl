/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/01 - I’m Not Invisible.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/02 - Remedy.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/03 - To Awake and Avenge the Dead.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/04 - Worms of the Universe.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/05 - Fields of Athenry.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/07 - Vacant Skies.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/09 - Noble Stabbings!!.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/10 - All My People.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/15 - All Systems Go.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/16 - One Seventeen.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/17 - All We Want.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/19 - Heaven Knows.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/20 - A Jackknife to a Swan.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/23 - Next to Go.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/24 - Be There.ogg
/home/nspyrd/Music/Various_Artists/Atticus: Dragging the Lake II/25 - Some Came Running.ogg
