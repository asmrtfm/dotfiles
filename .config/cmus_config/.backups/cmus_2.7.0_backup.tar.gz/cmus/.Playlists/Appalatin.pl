/home/nspyrd/Music/Appalatin/Appalatin(2011)/01 - Canta Mí Gente.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/02 - Luna Llena.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/03 - Carro Loco.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/04 - Vamos al Campo.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/05 - Sueños de Mar.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/06 - Spread the Love Around.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/07 - Pine Mountain Top.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/08 - Eva.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/09 - Mujeres y Niños.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/10 - Gotita de Lluvia,Shady Grove.ogg
/home/nspyrd/Music/Appalatin/Appalatin(2011)/11 - Where the River Flows.ogg
